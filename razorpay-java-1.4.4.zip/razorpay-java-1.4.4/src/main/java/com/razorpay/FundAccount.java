package com.razorpay;

import org.json.JSONObject;

public class FundAccount extends Entity {

  public FundAccount(JSONObject jsonObject) {
    super(jsonObject);
  }
}