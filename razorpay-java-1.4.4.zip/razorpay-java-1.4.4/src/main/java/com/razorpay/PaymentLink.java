package com.razorpay;

import org.json.JSONObject;

public class PaymentLink extends Entity {

    public PaymentLink(JSONObject jsonObject) {
        super(jsonObject);
    }
}
