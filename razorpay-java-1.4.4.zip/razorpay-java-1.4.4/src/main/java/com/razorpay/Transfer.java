package com.razorpay;

import org.json.JSONObject;

public class Transfer extends Entity {

  public Transfer(JSONObject jsonObject) {
    super(jsonObject);
  }
}
