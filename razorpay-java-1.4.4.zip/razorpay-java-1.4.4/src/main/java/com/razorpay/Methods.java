package com.razorpay;

import org.json.JSONObject;

public class Methods extends Entity {

    public Methods(JSONObject jsonObject) {
        super(jsonObject);
    }
}
