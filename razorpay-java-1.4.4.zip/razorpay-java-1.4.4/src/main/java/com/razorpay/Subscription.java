package com.razorpay;

import org.json.JSONObject;

public class Subscription extends Entity {

  public Subscription(JSONObject jsonObject) {
    super(jsonObject);
  }
}
